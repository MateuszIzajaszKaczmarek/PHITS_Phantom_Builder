## v0.1.3 — poprawka parsera sekcji

Rozpoznaje nagłówki PHITS z dodatkowymi przełącznikami, np. `[t-track] %switch%`, oraz nagłówki z odstępami pomiędzy literami, np. `[ T i t l e ]`. Dodano plik testowy `examples/jaszczak_geometry.inp`; jego import potwierdzono (312 powierzchni, 38 komórek, 6 transformacji). To nie oznacza jeszcze potwierdzenia poprawności eksportu STL całego fantomu; model jest duży i wymaga właściwego ograniczenia obszaru eksportu.

# PHITS Phantom Builder (wersja prototypowa 0.1)

Program w Pythonie zamienia **rzeczywiste granice pomiędzy komórkami PHITS** na ścianki o zadanej grubości, a następnie eksportuje je jako zamkniętą siatkę trójkątną **STL** do przygotowania druku 3D.

**Ważne:** to działający, przetestowany **prototyp dla podzbioru składni PHITS 3.35**, a nie ogólny konwerter każdego pliku PHITS. Nie generuje dokładnych modeli CAD/STEP. W przypadkach nieobsługiwanych stara się zgłosić błąd zamiast produkować mylną geometrię. Przed drukiem i przed eksperymentem zweryfikuj kształt, wymiary oraz szczelność wydruku.

## Jak działa?

1. Odczytuje sekcje `[Surface]`, `[Cell]` i `[Transform]` pliku `.inp`.
2. Odtwarza przypisanie punktów siatki przestrzennej do komórek, również z operacjami `AND` (spacja), `OR` (`:`) i `NOT` (`#`) oraz z obrotami/przesunięciami.
3. Wyszukuje **wyłącznie granice między komórkami** (nie wszystkie powierzchnie w `[Surface]`).
4. Pomija każdy styk z komórką `outer void` (`mat=-1`).
5. Domyślnie pozostawia przegrody nawet między komórkami o tym samym materiale. Opcja **Łącz sąsiednie komórki...** usuwa ścianki dla identycznej pary `(numer materiału, gęstość)`. Dwie komórki z takim samym numerem materiału, ale inną gęstością, pozostają rozdzielone.
6. Nadaje ściankom nominalną grubość symetrycznie względem granicy; przy skrzyżowaniach scala je w jeden zbiór wokseli.
7. Eksportuje `STL` (milimetry) oraz `JSON` z informacjami o siatce i przybliżonych **oryginalnych** objętościach komórek.

## Instalacja (Windows 10/11)

Zainstaluj **Python 3.11 lub 3.12**. Rozpakuj ZIP i uruchom dwukrotnie `uruchom_windows.bat`.

Skrypt wykrywa lokalną instalację Pythona, tworzy osobne środowisko `.venv` w katalogu programu, instaluje tam zależności i uruchamia aplikację przez konkretny `python.exe`. Dzięki temu nie podmienia bibliotek w innych projektach i nie zależy od aliasu Microsoft Store `python`.

Alternatywnie, w PowerShell/CMD w katalogu programu (jeśli działa `py -3.12`):

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

Jeżeli masz wcześniejszą instalację z v0.1, jej pakiety zostały zainstalowane globalnie; nowy skrypt ich nie zmienia. Jeśli potrzebujesz przywrócić kompatybilność globalnego Matplotliba z NumPy, użyj:

```powershell
& "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" -m pip install "numpy>=1.26.4,<2"
```

Na Linux/macOS z dostępnym Tkinterem:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py
```

## Obsługa okna

1. Kliknij **Otwórz…** i wskaż `.inp`.
2. Wprowadź **zakres obliczeń (xmin, xmax, ymin, ymax, zmin, zmax)** w **centymetrach PHITS**. Zakres musi obejmować *cały fizyczny obiekt, którego ścianki drukujesz*, z niewielkim marginesem. Zbyt mały zakres ucina bryłę; w JSON wyświetli się ostrzeżenie `clipped_faces`.
3. Ustaw **grubość ścianki [mm]** i **dokładność siatki [mm]**. Rozdzielczość musi być nie większa niż połowa grubości. Dla ścianki 1.5 mm rozdzielczość 0.5 mm jest rozsądnym pierwszym testem, a 0.25 mm poprawia szczegóły.
4. Opcjonalnie zaznacz **Łącz sąsiednie komórki o tym samym materiale i gęstości**.
5. Kliknij **Generuj STL** i otwórz plik `.stl` w slicerze (np. PrusaSlicer, Cura, Bambu Studio) albo programie CAD do kontroli.

**Limit domyślny**: 12 milionów próbek siatki. Program odmawia większej siatki, by ograniczyć zużycie RAM. Dla większych fantomów zwiększ rozdzielczość liczbową `pitch` (większe mm = mniej próbek), zmniejsz zakres lub użyj opcji `--max-voxels` w CLI na komputerze z odpowiednią ilością pamięci. Ta wersja może zużywać kilkaset MB lub więcej RAM, bo klasyfikuje pełną siatkę 3D.

## Uruchamianie z konsoli

Przykład: dwie sferyczne granice i ściana sześcianu, wszystkie w zakresie ±5.5 cm:

```bash
python main.py examples/spheres.inp \
  --bounds -5.5 5.5 -5.5 5.5 -5.5 5.5 \
  --thickness 1.5 --pitch 0.5 \
  -o spheres_walls.stl
```

Na Windows PowerShell wpisz powyższe jako **jedną linię** (bez `\`).

Pomijanie przegród między identycznymi materiałami:

```bash
python main.py examples/spheres.inp --bounds -5.5 5.5 -5.5 5.5 -5.5 5.5 --thickness 1.5 --pitch 0.5 --merge-same -o spheres_merged.stl
```

Pomoc: `python main.py --help`.

## Konstrukcje PHITS wspierane przez tę wersję

- `[Surface]`: `P` (4 lub 9 parametrów), `PX`, `PY`, `PZ`, `SO`, `S`, `SX`, `SY`, `SZ`, `CX`, `CY`, `CZ`, `C/X`, `C/Y`, `C/Z`, `SQ`, `GQ`; makrobryły `RPP`, `SPH`, `BOX`, `RCC`, `TRC`.
- `[Cell]`: liczby powierzchni ze znakiem, nawiasy, przecięcie (spacja), suma `:`, dopełnienie `#cell` i `#(...)`, domyślne `#all` jako osobna komórka (przy niezależnie określonym outer void).
- `[Transform]`: `TRn` i `*TRn`, typy `M=±1`, `M=±2`, `M=±3`; przypisanie numeru transformacji do powierzchni i `TRCL=n` do komórki.
- Liczby z notacją Fortrana `D`, proste wyrażenia i zmienne `set: cN[...]` (w tym `pi`, `sin`, `cos`, `sqrt` itd.).
- Sekcje nieużywane do geometrii mogą pozostać w pliku (np. source, tally, materiał).

## Ograniczenia wymagające uwagi

- **Nieobsługiwane**: `U=`, `FILL=`, `LAT=`, powtarzane struktury / universe / lattice, `LIKE ... BUT`, `TRCL=(...)`, podpowierzchnie makrobrył `10.1`, niektóre pozostałe powierzchnie (`RHP/HEX`, `REC`, `ELL`, `WED`, torusy `TX/TY/TZ`, stożki `K*`). Niektóre bardziej zaawansowane formaty kontynuacji linii, sterowanie odczytem, makra znakowe i inne szczególne zapisy PHITS też mogą wymagać dostosowania parsera.
- Jeśli plik używa `infl:`, przygotuj wcześniej rozwinięty plik `*_rwt.inp` (PHITS `$RWT=3`) i użyj go jako wejścia. Program nie rozwija automatycznie dołączonych plików.
- Dokładność jest **numeryczna i ograniczona krokiem `pitch`**. Powierzchnie nachylone mogą mieć schodkowanie, a faktyczna grubość odchylenia rzędu kroku; STL nie jest bryłą NURBS/STEP. Nie należy traktować wymiarów jako dokładnych metrologicznie bez sprawdzenia.
- Operacje na siatce i późniejszy slicing mogą spowodować utratę szczegółów. Siatka może zawierać **oddzielne, zamknięte skorupy** (np. dwie koncentryczne sfery); do realnego druku może być konieczny podział konstrukcji i zaprojektowanie połączeń.
- Program **nie dodaje** automatycznie korków, pokryw, otworów wlewowych ani odpowietrzeń; nie generuje też zaktualizowanego pliku PHITS z plastikiem. Oryginalne objętości w raporcie nie są rzeczywistą pojemnością płynową po wprowadzeniu przegród.
- Powietrze otaczające fantom w granicach zwykłej komórki nadal jest traktowane jako komórka i jej styki otrzymają ściankę. Tylko granice z `mat=-1` są pomijane.
- Jeśli ścianka dotyka granic wybranego zakresu, zostanie ostrzeżenie — siatka może być sztucznie zamknięta na płaszczyźnie cięcia. Rozszerz zakres i powtórz eksport.
- **Bezpieczeństwo i walidacja**: nie używaj gotowego wydruku jako certyfikowanego pojemnika na materiał niebezpieczny/radioaktywny. Przed eksperymentem sprawdź w slicerze STL, zmierz wymiary fantomu, wykonaj próbę szczelności i zmodyfikuj model transportowy PHITS, uwzględniając przegrody, jeżeli są istotne dla wymaganej dokładności.

## Testy

Zainstaluj `pytest` (`python -m pip install pytest`) i uruchom:

```bash
python -m pytest -q
```

Testy obejmują m.in. wykrywanie outer void, obroty, transformacje powierzchni i komórek, regułę scalania materiałów, boolean CSG, generowanie szczelnego STL oraz zgłaszanie nieobsługiwanych konstrukcji.

## Autorstwo i licencja

Kod wygenerowany jako projekt startowy, do dowolnego rozwijania i weryfikacji w zespole. W dokumentacji opierano się na *PHITS User's Manual, version 3.35*, rozdziały 4.4, 4.6, 5.5–5.7. Program nie zawiera kodu PHITS ani bibliotek danych nuklearnych.
