@echo off
setlocal
cd /d "%~dp0"
set "VENV_PY=%~dp0.venv\Scripts\python.exe"
set "PYTHON_EXE="
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYTHON_EXE=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PYTHON_EXE if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PYTHON_EXE=%LocalAppData%\Programs\Python\Python311\python.exe"

if not exist "%VENV_PY%" (
    echo Tworzenie osobnego srodowiska Python .venv ...
    if defined PYTHON_EXE (
        "%PYTHON_EXE%" -m venv ".venv"
    ) else (
        py -3.12 -m venv ".venv" 2>nul
        if errorlevel 1 py -3.11 -m venv ".venv" 2>nul
        if errorlevel 1 py -3 -m venv ".venv" 2>nul
    )
    if not exist "%VENV_PY%" (
        echo BLAD: Nie udalo sie utworzyc srodowiska Python.
        pause
        exit /b 1
    )
)

echo Instalowanie bibliotek wewnatrz .venv ...
"%VENV_PY%" -m pip install -r requirements.txt
if errorlevel 1 (
    echo BLAD: Nie udalo sie zainstalowac bibliotek.
    pause
    exit /b 1
)

echo Uruchamianie PHITS Phantom Builder ...
"%VENV_PY%" "%~dp0main.py"
if errorlevel 1 (
    echo BLAD: Program zakonczyl sie bledem.
    pause
)
endlocal
