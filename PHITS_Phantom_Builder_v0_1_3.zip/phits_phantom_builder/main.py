#!/usr/bin/env python3
"""PHITS Phantom Builder — CLI and Tkinter GUI."""
from __future__ import annotations
import argparse
import json
import sys
import traceback
from pathlib import Path
from phits_geometry import parse_inp, GeometryError
from phantom_mesh import BuildOptions, generate_mesh


def build(src, dst, bounds, thickness, pitch, merge, max_voxels=12_000_000):
    geom=parse_inp(src)
    return generate_mesh(geom,BuildOptions(tuple(bounds),thickness,pitch,merge,max_voxels),dst)


def cli():
    p=argparse.ArgumentParser(description='PHITS .inp -> STL centered walls between cells (PHITS 3.35 subset).')
    p.add_argument('input',help='PHITS .inp file')
    p.add_argument('-o','--output',help='Output .stl file (default: input name + _walls.stl)')
    p.add_argument('--bounds',required=True,nargs=6,type=float,
                   metavar=('XMIN','XMAX','YMIN','YMAX','ZMIN','ZMAX'),
                   help='Crop region in PHITS centimeters')
    p.add_argument('--thickness',type=float,default=1.5,help='Nominal wall thickness [mm]')
    p.add_argument('--pitch',type=float,default=0.35,help='Voxel pitch [mm]; <= thickness/2')
    p.add_argument('--merge-same',action='store_true',help='Omit walls between same (material,density)')
    p.add_argument('--max-voxels',type=int,default=12_000_000)
    a=p.parse_args()
    out=a.output or str(Path(a.input).with_name(Path(a.input).stem+'_walls.stl'))
    try:
        info=build(a.input,out,a.bounds,a.thickness,a.pitch,a.merge_same,a.max_voxels)
        print('Wygenerowano:',out)
        print(json.dumps(info,indent=2,ensure_ascii=False))
    except (GeometryError,OSError,ValueError) as exc:
        print('BŁĄD:',exc,file=sys.stderr); sys.exit(2)


def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    from concurrent.futures import ThreadPoolExecutor
    root=tk.Tk(); root.title('PHITS Phantom Builder 0.1'); root.geometry('800x650')
    frame=ttk.Frame(root,padding=15);frame.pack(fill='both',expand=True)
    frame.columnconfigure(1,weight=1)
    filepath=tk.StringVar(); output=tk.StringVar()
    merge=tk.BooleanVar(value=False)
    thick=tk.StringVar(value='1.5');pitch=tk.StringVar(value='0.5')
    coords=[tk.StringVar(value=x) for x in ('-5','5','-5','5','-5','5')]
    status=tk.StringVar(value='Otwórz plik PHITS .inp i ustaw granice obszaru eksportu w cm.')
    r=0
    ttk.Label(frame,text='Plik PHITS (.inp)').grid(row=r,column=0,sticky='w',pady=5)
    ttk.Entry(frame,textvariable=filepath).grid(row=r,column=1,sticky='ew',padx=7)
    def select_file():
        f=filedialog.askopenfilename(filetypes=[('PHITS','*.inp'),('Wszystkie pliki','*.*')])
        if f:
            filepath.set(f);output.set(str(Path(f).with_name(Path(f).stem+'_walls.stl')))
            try:
                g=parse_inp(f)
                status.set(f'Wczytano: {len(g.cells)} komórek, {len(g.surfaces)} powierzchni, {len(g.transforms)} transformacji.')
                tree.delete(*tree.get_children())
                for c in g.cells.values():
                    tree.insert('', 'end',values=(c.id,c.material,c.density,c.trcl or '–'))
            except Exception as e: status.set('BŁĄD PARSERA: '+str(e))
    ttk.Button(frame,text='Otwórz…',command=select_file).grid(row=r,column=2)
    r+=1
    ttk.Label(frame,text='Zapisz STL').grid(row=r,column=0,sticky='w',pady=5)
    ttk.Entry(frame,textvariable=output).grid(row=r,column=1,sticky='ew',padx=7)
    ttk.Button(frame,text='Wybierz…',command=lambda:output.set(filedialog.asksaveasfilename(defaultextension='.stl',filetypes=[('STL','*.stl')]))).grid(row=r,column=2)
    r+=1
    ttk.Label(frame,text='Obszar eksportu [cm]').grid(row=r,column=0,sticky='w',pady=8)
    sub=ttk.Frame(frame);sub.grid(row=r,column=1,sticky='ew')
    for j,name in enumerate(('xmin','xmax','ymin','ymax','zmin','zmax')):
        ttk.Label(sub,text=name).grid(row=0,column=j)
        ttk.Entry(sub,textvariable=coords[j],width=8).grid(row=1,column=j,padx=3)
    r+=1
    ttk.Label(frame,text='Grubość ścianek [mm]').grid(row=r,column=0,sticky='w',pady=8)
    ttk.Entry(frame,textvariable=thick,width=12).grid(row=r,column=1,sticky='w')
    r+=1
    ttk.Label(frame,text='Dokładność siatki [mm]').grid(row=r,column=0,sticky='w',pady=8)
    ttk.Entry(frame,textvariable=pitch,width=12).grid(row=r,column=1,sticky='w')
    r+=1
    ttk.Checkbutton(frame,text='Łącz sąsiednie komórki o tym samym materiale i gęstości',variable=merge).grid(row=r,column=0,columnspan=3,sticky='w',pady=9)
    r+=1
    ttk.Label(frame,text='Komórki (informacyjnie)').grid(row=r,column=0,columnspan=3,sticky='w')
    r+=1
    tree=ttk.Treeview(frame,columns=('id','mat','rho','trcl'),show='headings',height=8)
    for c,label,width in [('id','Komórka',100),('mat','Materiał',100),('rho','Gęstość',120),('trcl','Transformacja',130)]:
        tree.heading(c,text=label);tree.column(c,width=width)
    tree.grid(row=r,column=0,columnspan=3,sticky='nsew',pady=8);frame.rowconfigure(r,weight=1)
    r+=1
    log=tk.Text(frame,height=8,wrap='word');log.grid(row=r,column=0,columnspan=3,sticky='ew')
    r+=1
    executor=ThreadPoolExecutor(max_workers=1)
    def finished(fut):
        def update():
            go.config(state='normal')
            try:
                info=fut.result()
                msg=f'Zapisano: {output.get()}\nSiatka: {info["grid_shape"]}\nTrójkąty: {info["mesh_triangles"]}\nSzczelność siatki STL: {info["mesh_watertight"]}\n'
                if info['warnings']: msg+='\n'+'\n'.join(info['warnings'])
                log.insert('end',msg+'\n\n');log.see('end');status.set('Zakończono eksport STL.')
            except Exception as exc:
                log.insert('end',f'BŁĄD: {exc}\n\n');log.see('end');status.set('Błąd eksportu.')
                messagebox.showerror('Błąd PHITS Phantom Builder',str(exc))
        root.after(0,update)
    def generate():
        try:
            if not filepath.get() or not output.get(): raise GeometryError('Wybierz plik wejściowy i wyjściowy.')
            bounds=[float(v.get().replace(',','.')) for v in coords]
            t=float(thick.get().replace(',','.'));h=float(pitch.get().replace(',','.'))
            go.config(state='disabled');status.set('Obliczanie granic i tworzenie siatki STL…')
            fut=executor.submit(build,filepath.get(),output.get(),bounds,t,h,merge.get())
            fut.add_done_callback(finished)
        except Exception as exc: messagebox.showerror('Niepoprawne parametry',str(exc))
    go=ttk.Button(frame,text='Generuj STL',command=generate)
    go.grid(row=r,column=0,columnspan=3,sticky='ew',pady=10)
    r+=1
    ttk.Label(frame,textvariable=status,wraplength=720).grid(row=r,column=0,columnspan=3,sticky='w')
    root.mainloop();executor.shutdown(wait=False)


if __name__=='__main__':
    if len(sys.argv)>1: cli()
    else:
        try: gui()
        except Exception as exc:
            print('Nie udało się uruchomić GUI:',exc,file=sys.stderr)
            print('Uruchom `python main.py --help` w trybie konsolowym.',file=sys.stderr)
            sys.exit(1)
