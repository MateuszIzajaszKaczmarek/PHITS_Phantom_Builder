"""Voxel interface reconstruction and wall meshing.

Walls are placed on ACTUAL interfaces between separately defined cells. Their
nominal centerplanes are the PHITS boundaries; discretization error is governed
by pitch_mm. Outer-void surfaces are excluded.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import numpy as np
from scipy.ndimage import distance_transform_edt
from skimage.measure import marching_cubes
import trimesh

from phits_geometry import Geometry, GeometryError


@dataclass
class BuildOptions:
    bounds_cm: tuple[float, float, float, float, float, float]
    thickness_mm: float = 1.5
    pitch_mm: float = 0.35
    merge_same_material: bool = False
    max_voxels: int = 12_000_000


def generate_mesh(geometry: Geometry, options: BuildOptions,
                  outfile: str | Path) -> dict:
    b=np.asarray(options.bounds_cm,dtype=float)
    if not np.all(np.isfinite(b)) or np.any(b[[1,3,5]] <= b[[0,2,4]]):
        raise GeometryError('Bounds: każda górna granica musi być większa od dolnej.')
    if not (0.05 <= options.pitch_mm <= 10):
        raise GeometryError('Rozdzielczość pitch musi mieścić się w zakresie 0.05–10 mm.')
    if not (0.1 <= options.thickness_mm <= 50):
        raise GeometryError('Grubość ścianek musi wynosić 0.1–50 mm.')
    if options.pitch_mm > options.thickness_mm / 2:
        raise GeometryError('Aby poprawnie reprezentować grubość, pitch musi być <= thickness/2.')
    lo=b[[0,2,4]]; hi=b[[1,3,5]]
    length_mm=(hi-lo)*10.0
    counts=np.ceil(length_mm/options.pitch_mm).astype(int)
    voxel_count=int(np.prod(counts, dtype=np.int64))
    if voxel_count>options.max_voxels:
        raise GeometryError(
            f'Za duża siatka: {voxel_count:,} voxeli (limit {options.max_voxels:,}). '
            'Zwiększ pitch albo zmniejsz zakres XYZ.')
    if np.any(counts<3): raise GeometryError('Zbyt mały zakres XYZ dla tej rozdzielczości.')
    step_cm=(hi-lo)/counts
    step_mm=step_cm*10.0

    labels=np.empty(tuple(counts),dtype=np.int32)
    # Batch along x to limit temporary array memory.
    yy=lo[1]+(np.arange(counts[1])+0.5)*step_cm[1]
    zz=lo[2]+(np.arange(counts[2])+0.5)*step_cm[2]
    for start in range(0,int(counts[0]),10):
        stop=min(start+10,int(counts[0]))
        xx=lo[0]+(np.arange(start,stop)+0.5)*step_cm[0]
        p=np.empty((len(xx),len(yy),len(zz),3),dtype=np.float64)
        p[...,0]=xx[:,None,None]; p[...,1]=yy[None,:,None]; p[...,2]=zz[None,None,:]
        labels[start:stop]=geometry.classify(p)
    if np.any(labels==-9999):
        n=int((labels==-9999).sum())
        raise GeometryError(f'{n:,} próbek nie należy do żadnej komórki PHITS. '
                            'Sprawdź domknięcie geometrii lub ustaw bounds wewnątrz modelu.')
    # Map cell IDs to grouping IDs; negative -1 indicates outer void.
    group=np.empty_like(labels)
    groups={}
    next_group=1
    outer_ids=set()
    for c in geometry.cells.values():
        if c.material==-1:
            outer_ids.add(c.id); group[labels==c.id]=-1
            continue
        # Distinct groups by default; optional merging by BOTH material and density.
        key=(c.material,c.density) if options.merge_same_material else (c.id,)
        if key not in groups:
            groups[key]=next_group; next_group+=1
        group[labels==c.id]=groups[key]
    # Seed volumes on both sides of each interface. Discard boundaries with outer void.
    interface=np.zeros(labels.shape,dtype=bool)
    for axis in range(3):
        sa=[slice(None)]*3; sb=[slice(None)]*3
        sa[axis]=slice(None,-1); sb[axis]=slice(1,None)
        sa=tuple(sa);sb=tuple(sb)
        ga,gb=group[sa],group[sb]
        change=(ga!=gb) & (ga!=-1) & (gb!=-1)
        interface[sa] |= change
        interface[sb] |= change
    if not interface.any():
        raise GeometryError('Brak granic do wydruku w wybranym obszarze.')
    # For each seeded voxel, its center is ~half a pitch from the mathematical
    # interface. The -pitch/2 correction gives a centered wall in 1D; curved
    # and oblique interfaces remain approximate on the finite voxel grid.
    min_spacing=float(step_mm.min())
    radius=max(0.0,options.thickness_mm/2-min_spacing/2)
    if radius<1e-9:
        wall=interface
    else:
        distances=distance_transform_edt(~interface,sampling=tuple(step_mm))
        wall=distances<=radius+1e-9
        del distances
    touches=[]
    for ax,name in enumerate('xyz'):
        for idx,side in ((0,'min'),(-1,'max')):
            s=[slice(None)]*3;s[ax]=idx
            if np.any(wall[tuple(s)]): touches.append(f'{name}{side}')
    # Outside padded 0 cells close mesh at ROI edges. Warn as this may create
    # artificial caps on clipped geometry.
    padded=np.pad(wall,1,constant_values=False)
    vertices, faces, _normals, _vals=marching_cubes(
        padded.astype(np.uint8),level=0.5,spacing=tuple(step_mm))
    # marching cubes output positions correspond to padded voxel centers
    # padded index zero is the center at lo - 0.5 * spacing.
    vertices += (lo*10.0-0.5*step_mm)
    mesh=trimesh.Trimesh(vertices=vertices,faces=faces,process=True)
    outfile=Path(outfile)
    outfile.parent.mkdir(parents=True,exist_ok=True)
    if outfile.suffix.lower()!='.stl':
        raise GeometryError('Format wyjściowy tej wersji to .stl')
    mesh.export(str(outfile),file_type='stl')
    # Volume estimate counts original cell voxels (without wall removal).
    voxel_vol_cm3=float(np.prod(step_cm))
    cell_volumes={str(c.id):round(int((labels==c.id).sum())*voxel_vol_cm3,4)
                  for c in geometry.cells.values() if c.material!=-1}
    info={
        'source_units':'PHITS cm', 'stl_units':'mm',
        'bounds_cm':list(map(float,b)), 'grid_shape':list(map(int,counts)),
        'actual_spacing_mm':list(map(float,step_mm)),
        'nominal_thickness_mm':options.thickness_mm,
        'merge_same_material':options.merge_same_material,
        'wall_voxels':int(wall.sum()), 'mesh_vertices':len(mesh.vertices),
        'mesh_triangles':len(mesh.faces), 'mesh_watertight':bool(mesh.is_watertight),
        'clipped_faces':touches,
        'raw_cell_volumes_cm3':cell_volumes,
        'warnings':([
            'Ścianki dotykają granicy wybranego obszaru: '+', '.join(touches)+
            '. Mesh może mieć sztuczne zamknięcia. Zwiększ bounds.'
        ] if touches else []) + [
            'STL jest aproksymacją wokselową, nie ścisłą reprezentacją CAD.',
            'Podane objętości są objętościami oryginalnych komórek PHITS, '
            'a nie objętościami cieczy po wstawieniu przegród.'
        ]
    }
    outfile.with_suffix('.json').write_text(json.dumps(info,indent=2,ensure_ascii=False),encoding='utf-8')
    return info
