"""Subset of PHITS 3.35 CSG geometry, with strict unsupported-feature checking.

All geometry coordinates are in PHITS centimetres. Output generation uses mm.
See PHITS User's Manual 3.35, sections 4.4, 4.6, 5.5, 5.6 and 5.7.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
import math
import re
from typing import Any

import numpy as np


class GeometryError(ValueError):
    """Invalid or unsupported input; fail rather than silently change geometry."""


_FUNCS = {k: getattr(math, k) for k in ('sin', 'cos', 'tan', 'asin', 'acos', 'atan',
                                        'sqrt', 'exp', 'log', 'sinh', 'cosh', 'tanh')}
_FUNCS.update({'abs': abs, 'min': min, 'max': max, 'atan2': math.atan2,
               'log10': math.log10, 'float': float, 'int': int})


def number(token: str, variables: dict[str, float] | None = None) -> float:
    """Restricted calculator; never uses eval() on input files."""
    expr = token.strip().strip('{}').replace('^', '**')
    expr = re.sub(r'(?i)(\d(?:\.\d*)?|\.\d+)[d]([+-]?\d+)', r'\1e\2', expr)
    names: dict[str, Any] = {'pi': math.pi, 'e': math.e, **_FUNCS, **(variables or {})}
    try:
        tree = ast.parse(expr, mode='eval')
        def walk(n):
            if isinstance(n, ast.Expression): return walk(n.body)
            if isinstance(n, ast.Constant) and type(n.value) in (int, float): return float(n.value)
            if isinstance(n, ast.Name) and n.id.lower() in names: return names[n.id.lower()]
            if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
                val = walk(n.operand); return val if isinstance(n.op, ast.UAdd) else -val
            if isinstance(n, ast.BinOp) and type(n.op) in (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow):
                a, b = walk(n.left), walk(n.right)
                return {ast.Add: lambda: a+b, ast.Sub: lambda: a-b,
                        ast.Mult: lambda: a*b, ast.Div: lambda: a/b,
                        ast.Pow: lambda: a**b}[type(n.op)]()
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id.lower() in _FUNCS:
                if n.keywords: raise GeometryError('Keyword arguments are not allowed')
                return _FUNCS[n.func.id.lower()](*(walk(a) for a in n.args))
            raise GeometryError(f'Nieobsługiwane wyrażenie matematyczne: {expr}')
        value = float(walk(tree))
        if not math.isfinite(value): raise ValueError('not finite')
        return value
    except (SyntaxError, ValueError, TypeError, ZeroDivisionError, OverflowError, KeyError) as exc:
        raise GeometryError(f'Nie można obliczyć: {token!r} ({exc})') from exc


def argsplit(line: str) -> list[str]:
    """Whitespace-separated arguments, with {expression containing spaces} as one token."""
    return re.findall(r'\{[^{}]*\}|\S+', line)


def rotation_xyz(axis: str, a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    if axis == 'x': return np.array([[1, 0, 0], [0,c,-s], [0,s,c]])
    if axis == 'y': return np.array([[c,0,s], [0,1,0], [-s,0,c]])
    return np.array([[c,-s,0], [s,c,0], [0,0,1]])


@dataclass
class Transform:
    """Coordinates global = R @ local + t (plus in PHITS means object transform)."""
    rotation: np.ndarray = field(default_factory=lambda: np.eye(3))
    translation: np.ndarray = field(default_factory=lambda: np.zeros(3))

    def inverse_points(self, xyz: np.ndarray) -> np.ndarray:
        # row-vector convention, rhs is a batch of [x,y,z]
        return (xyz - self.translation) @ self.rotation

    def combine(self, inner: 'Transform') -> 'Transform':
        """self(inner(point))."""
        return Transform(self.rotation @ inner.rotation,
                         self.rotation @ inner.translation + self.translation)


def make_transform(spec: str, variables: dict[str, float]) -> Transform:
    tok = argsplit(spec)
    if len(tok) < 4 or not re.fullmatch(r'\*?tr\d+', tok[0], re.I):
        raise GeometryError(f'Niepoprawna transformacja: {spec}')
    deg = tok[0].startswith('*')
    vals = [number(t, variables) for t in tok[1:]]
    if len(vals) < 3: raise GeometryError('TR wymaga co najmniej X0 Y0 Z0')
    raw_trans = np.array(vals[:3], dtype=float)
    b = vals[3:12]
    mode = round(vals[12]) if len(vals) == 13 else 1
    if len(vals) not in (3, 12, 13):
        raise GeometryError('TR: oczekiwano 3, 12 lub 13 parametrów (bez nazwy).')
    if len(vals) == 3: rot = np.eye(3)
    elif abs(mode) == 1:
        # PHITS B1,B2,B3 are the first COLUMN, not row.
        rot = np.array(b).reshape((3,3)).T
        if not np.allclose(rot.T @ rot, np.eye(3), atol=1e-4) or np.linalg.det(rot) < 0.99:
            raise GeometryError('TR macierz musi być prawoskrętną macierzą obrotu (ORTOGONALNA).')
    elif abs(mode) == 2:
        theta_z, theta_y, theta_x = b[:3]
        if deg: theta_z, theta_y, theta_x = np.deg2rad([theta_z,theta_y,theta_x])
        rot = rotation_xyz('x', theta_x) @ rotation_xyz('y', theta_y) @ rotation_xyz('z', theta_z)
    elif abs(mode) == 3:
        center = np.array(b[:3])
        rot = np.eye(3)
        for axis_num, angle in ((b[3],b[4]),(b[5],b[6]),(b[7],b[8])):
            axis_num = round(axis_num)
            if axis_num == 0: continue
            if axis_num not in (1,2,3): raise GeometryError(f'TR M=3: nieznana oś {axis_num}')
            if deg: angle = math.radians(angle)
            rot = rotation_xyz('xyz'[axis_num-1], angle) @ rot
        if mode > 0: return Transform(rot, center - rot @ center + raw_trans)
        return Transform(rot, center - rot @ (center + raw_trans))
    else:
        raise GeometryError(f'Nieobsługiwany wariant TR M={mode}')
    # PHITS M<0 translates first with opposite sign (see manual 5.7.2)
    return Transform(rot, raw_trans if mode > 0 else -rot @ raw_trans)


@dataclass
class Surface:
    id: int
    kind: str
    data: tuple[float, ...]
    transform: Transform = field(default_factory=Transform)

    def sign(self, p: np.ndarray, cell_transform: Transform | None = None) -> np.ndarray:
        transform = cell_transform.combine(self.transform) if cell_transform is not None else self.transform
        q = transform.inverse_points(p)
        x, y, z = q[..., 0], q[..., 1], q[..., 2]
        d = self.data; k = self.kind.upper()
        if k in ('PX','PY','PZ'):
            return q[..., {'PX':0,'PY':1,'PZ':2}[k]] - d[0]
        if k == 'P':
            if len(d) == 4: return d[0]*x+d[1]*y+d[2]*z-d[3]
            a, b, c = np.asarray(d).reshape(3,3)
            n = np.cross(b-a,c-a)
            if np.dot(n,a) > 0: n=-n  # origin is on negative side, manual P(9)
            return n[0]*(x-a[0])+n[1]*(y-a[1])+n[2]*(z-a[2])
        if k in ('SO','S','SX','SY','SZ','SPH'):
            if k == 'SO': center, radius = np.zeros(3), d[0]
            elif k in ('S','SPH'): center, radius = np.asarray(d[:3]), d[3]
            else:
                center=np.zeros(3); center[{'SX':0,'SY':1,'SZ':2}[k]]=d[0]; radius=d[1]
            return (x-center[0])**2+(y-center[1])**2+(z-center[2])**2-radius**2
        if k in ('CX','CY','CZ','C/X','C/Y','C/Z'):
            axis={'CX':0,'CY':1,'CZ':2,'C/X':0,'C/Y':1,'C/Z':2}[k]
            perp=[a for a in (0,1,2) if a!=axis]
            offset = (0,0) if len(d)==1 else d[:2]
            radius=d[-1]
            return (q[...,perp[0]]-offset[0])**2+(q[...,perp[1]]-offset[1])**2-radius**2
        if k=='SQ':
            a,b,c,dd,e,f,g,ox,oy,oz=d
            X,Y,Z=x-ox,y-oy,z-oz
            return a*X**2+b*Y**2+c*Z**2+2*dd*X+2*e*Y+2*f*Z+g
        if k=='GQ':
            a,b,c,dd,e,f,g,h,j,kk=d
            return a*x*x+b*y*y+c*z*z+dd*x*y+e*y*z+f*z*x+g*x+h*y+j*z+kk
        if k=='RPP':
            xmin,xmax,ymin,ymax,zmin,zmax=d
            return np.maximum.reduce([xmin-x, x-xmax, ymin-y, y-ymax, zmin-z, z-zmax])
        if k=='BOX':
            base=np.array(d[:3]); cols=np.array(d[3:]).reshape((3,3)).T
            try: uvw=(q-base) @ np.linalg.inv(cols).T
            except np.linalg.LinAlgError as exc: raise GeometryError('BOX o wektorach współliniowych') from exc
            return np.maximum.reduce([-uvw[...,0],uvw[...,0]-1,
                                      -uvw[...,1],uvw[...,1]-1,-uvw[...,2],uvw[...,2]-1])
        if k=='RCC':
            base=np.array(d[:3]); height=np.array(d[3:6]); radius=d[6]
            hh=float(np.dot(height,height))
            if hh <= 0: raise GeometryError('RCC o zerowej wysokości')
            v=q-base; proj=(v@height)/hh
            radial=v-proj[...,None]*height
            return np.maximum.reduce([np.linalg.norm(radial,axis=-1)-radius,
                                      -proj*math.sqrt(hh), (proj-1)*math.sqrt(hh)])
        if k=='TRC':
            base=np.array(d[:3]); height=np.array(d[3:6]); r0,r1=d[6:8]
            hh=float(np.dot(height,height))
            if hh <= 0: raise GeometryError('TRC o zerowej wysokości')
            v=q-base; proj=(v@height)/hh
            radial=v-proj[...,None]*height
            rad_at = r0+(r1-r0)*proj
            return np.maximum.reduce([np.linalg.norm(radial,axis=-1)-rad_at,
                                      -proj*math.sqrt(hh),(proj-1)*math.sqrt(hh)])
        raise GeometryError(f'Wewnętrzny błąd powierzchni: {self.kind}')


@dataclass
class Cell:
    id: int
    material: int
    density: float | None
    expr: Any
    trcl: int | None = None
    special_all: bool = False


@dataclass
class Geometry:
    surfaces: dict[int, Surface]
    cells: dict[int, Cell]
    transforms: dict[int, Transform]

    @property
    def cell_info(self) -> list[str]:
        return [f'{c.id}: mat={c.material}, rho={c.density}' for c in self.cells.values()]

    def classify(self, xyz: np.ndarray) -> np.ndarray:
        """Return cell-ID array, -9999 for missing/uncovered geometry, strict overlap check."""
        target_shape = xyz.shape[:-1]
        cache: dict[int,np.ndarray]={}
        stack: set[int]=set()
        def cellmask(cid: int):
            if cid in cache: return cache[cid]
            if cid in stack: raise GeometryError(f'Cykliczne odwołanie # do komórki {cid}')
            if cid not in self.cells: raise GeometryError(f'Odwołanie # do brakującej komórki {cid}')
            c=self.cells[cid]
            if c.special_all: raise GeometryError('#all nie może być użyte jako odwołanie przez #numer')
            stack.add(cid)
            trans=self.transforms.get(c.trcl) if c.trcl is not None else None
            def visit(node):
                op=node[0]
                if op=='surf':
                    sid=node[1]
                    if abs(sid) not in self.surfaces:
                        raise GeometryError(f'Nieznana powierzchnia {sid} w komórce {cid}')
                    sign=self.surfaces[abs(sid)].sign(xyz,trans)
                    return sign < 0 if sid<0 else sign > 0
                if op=='cellnot': return ~cellmask(node[1])
                if op=='not': return ~visit(node[1])
                if op=='and': return visit(node[1]) & visit(node[2])
                if op=='or': return visit(node[1]) | visit(node[2])
                raise GeometryError(f'Błąd AST {op}')
            mask=visit(c.expr)
            stack.remove(cid); cache[cid]=mask
            return mask

        result = np.full(target_shape,-9999,dtype=np.int32)
        # Explicit (non-outer) cells first; do not allow priority-overlap semantics.
        for c in self.cells.values():
            if c.material == -1 or c.special_all: continue
            mask=cellmask(c.id)
            if np.any(mask & (result!=-9999)):
                raise GeometryError(f'Geometria zawiera nakładające się komórki (m.in. {c.id})')
            result[mask]=c.id
        # Outer cells after regular ones; complement definitions can include explicitly labeled background.
        for c in self.cells.values():
            if c.material != -1: continue
            mask=cellmask(c.id)
            if np.any(mask & (result!=-9999)):
                raise GeometryError(f'Outer void {c.id} nakłada się na komórkę fizyczną.')
            result[mask]=c.id
        all_cells=[c for c in self.cells.values() if c.special_all]
        if len(all_cells)>1: raise GeometryError('PHITS dopuszcza najwyżej jedną komórkę #all.')
        if all_cells: result[result==-9999]=all_cells[0].id
        return result


def _parse_bool(s: str) -> Any:
    # Surface references: signed integer, #cell, #(...), ':' OR, whitespace AND.
    # A.B macrobody face syntax deliberately not supported; never silently floor it.
    pattern=r'\#all|\#|\(|\)|\:|[+-]?\d+(?:\.\d+)?|\S+'
    tokens=re.findall(pattern,s,re.I)
    if not tokens: raise GeometryError('Brak definicji geometrycznej komórki')
    i=0
    def primary():
        nonlocal i
        if i>=len(tokens): raise GeometryError(f'Niekompletne wyrażenie komórki: {s}')
        t=tokens[i]; i+=1
        if t=='(':
            v=union()
            if i>=len(tokens) or tokens[i]!=')': raise GeometryError('Nie zamknięto nawiasu w [Cell]')
            i+=1; return v
        if t=='#':
            v=primary()
            if v[0]=='surf':
                if v[1] < 0: raise GeometryError('#-n nie jest poprawnym odwołaniem do komórki')
                return ('cellnot',v[1])
            return ('not',v)
        if re.fullmatch(r'[+-]?\d+',t):
            v=int(t)
            if v==0: raise GeometryError('Numer powierzchni nie może wynosić 0')
            return ('surf',v)
        if re.fullmatch(r'[+-]?\d+\.\d+',t):
            raise GeometryError(f'Powierzchnie makrobrył z sufiksem .n nie są jeszcze obsługiwane: {t}')
        if t.lower()=='#all': raise GeometryError('#all może być tylko pełną definicją komórki')
        raise GeometryError(f'Nieobsługiwany token [Cell]: {t}')
    def intersection():
        nonlocal i
        n=primary()
        while i<len(tokens) and tokens[i] not in (':',')'):
            n=('and',n,primary())
        return n
    def union():
        nonlocal i
        n=intersection()
        while i<len(tokens) and tokens[i]==':':
            i+=1; n=('or',n,intersection())
        return n
    out=union()
    if i!=len(tokens): raise GeometryError(f'Nieprzetworzone tokeny [Cell]: {tokens[i:]}')
    return out


_SURFACE_ARGS={'P':(4,9),'PX':(1,),'PY':(1,),'PZ':(1,),
 'SO':(1,), 'S':(4,), 'SX':(2,), 'SY':(2,), 'SZ':(2,),
 'CX':(1,),'CY':(1,),'CZ':(1,), 'C/X':(3,),'C/Y':(3,),'C/Z':(3,),
 'SQ':(10,),'GQ':(10,), 'RPP':(6,),'BOX':(12,),'SPH':(4,),
 'RCC':(7,),'TRC':(8,)}


def parse_inp(filename: str | Path) -> Geometry:
    """Parse supported PHITS syntax; unsupported constructs raise GeometryError."""
    path=Path(filename)
    try: content=path.read_text(encoding='utf-8-sig')
    except UnicodeDecodeError: content=path.read_text(encoding='cp1252')
    variables:dict[str,float]={}
    sections:dict[str,list[tuple[str,dict[str,float]]]]={}
    section=''
    for no, raw in enumerate(content.splitlines(),1):
        stripped=raw.strip()
        if not stripped or re.match(r'^[cC]\s',stripped) or stripped.startswith('$'):
            continue
        # PHITS inline comments start with $, except directives like $RWT before sections.
        line=raw.split('$',1)[0].strip()
        if not line: continue
        if re.search(r'(?i)^infl\s*:',line) or re.search(r'(?i)^\s*\#include\b',line):
            raise GeometryError(f'Linia {no}: pliki INFL nie są obsługiwane. Użyj rozwiniętego *_rwt.inp z PHITS.')
        if line.lower().startswith('set:'):
            declarations=re.findall(r'(c\d+)\s*\[([^\]]+)\]',line,re.I)
            if not declarations:
                # unrelated user-defined text variables are not needed for geometry
                continue
            for key,val in declarations: variables[key.lower()]=number(val,variables)
            continue
        match=re.match(r'^\[\s*([^\]]+?)\s*\](?:\s|$)',line)
        if match:
            section=re.sub(r'\s+', '', match.group(1)).lower(); sections.setdefault(section,[])
            continue
        if section in ('surface','cell','transform'):
            sections[section].append((line,dict(variables)))

    def records(name: str):
        out=[]
        for line, var in sections.get(name,[]):
            tok=argsplit(line)
            if name == 'transform':
                isnew=bool(re.fullmatch(r'\*?tr\d+',tok[0],re.I))
            elif name == 'surface':
                # Surface continuations can begin with numerical coordinates.
                # A new record must contain a *recognized* surface symbol,
                # directly or after the optional transform number.
                isnew=bool(re.fullmatch(r'\*?\+?\d+',tok[0])) and (
                    (len(tok)>1 and tok[1].upper() in _SURFACE_ARGS) or
                    (len(tok)>2 and re.fullmatch(r'\d+',tok[1])
                     and tok[2].upper() in _SURFACE_ARGS))
            else:
                isnew=bool(re.fullmatch(r'\d+',tok[0])) and len(tok)>=3 and (
                    tok[1].lower()=='like' or
                    (re.fullmatch(r'-?\d+',tok[1]) and int(tok[1])>=-1))
            if isnew: out.append([line,dict(var)])
            elif out: out[-1][0]+=' '+line
            else: raise GeometryError(f'Nieoczekiwana linia w [{name}]: {line}')
        return out

    trans:dict[int,Transform]={}
    for spec, var in records('transform'):
        key=re.match(r'\*?tr(\d+)',spec,re.I)
        assert key
        tid=int(key.group(1))
        if tid in trans: raise GeometryError(f'Powtórzona transformacja TR{tid}')
        trans[tid]=make_transform(spec,var)
    surfaces:dict[int,Surface]={}
    for spec,var in records('surface'):
        tok=argsplit(spec)
        if len(tok)<3: raise GeometryError(f'Niepełna definicja powierzchni: {spec}')
        ident=tok.pop(0).lstrip('*+')
        sid=int(ident)
        # a transform number is present before the surface symbol when specified.
        trnum=None
        if re.fullmatch(r'[+-]?\d+',tok[0]): trnum=int(tok.pop(0))
        kind=tok.pop(0).upper()
        if kind not in _SURFACE_ARGS:
            raise GeometryError(f'Powierzchnia {sid}: typ {kind} nie jest obsługiwany w tej wersji.')
        nums=tuple(number(t,var) for t in tok)
        if len(nums) not in _SURFACE_ARGS[kind]:
            raise GeometryError(f'Powierzchnia {sid} ({kind}) ma {len(nums)} parametrów, oczekiwano {_SURFACE_ARGS[kind]}')
        if trnum is not None and trnum not in trans:
            raise GeometryError(f'Powierzchnia {sid} odwołuje się do nieistniejącego TR{trnum}')
        if sid in surfaces: raise GeometryError(f'Powtórzona powierzchnia {sid}')
        surfaces[sid]=Surface(sid,kind,nums,trans.get(trnum,Transform()))
    cells:dict[int,Cell]={}
    for spec,var in records('cell'):
        tok=argsplit(spec)
        if len(tok)<3: raise GeometryError(f'Niepełna komórka: {spec}')
        cid=int(tok.pop(0)); mt=tok.pop(0)
        if mt.lower()=='like':
            raise GeometryError(f'Komórka {cid}: LIKE n BUT nie jest obsługiwane (użyj jawnych komórek).')
        mat=int(mt)
        density=None
        if mat>=1:
            if not tok: raise GeometryError(f'Komórka {cid} nie ma gęstości')
            density=number(tok.pop(0),var)
        remaining=' '.join(tok)
        # PHITS cell keywords are used after the geometry definition.
        kw=re.search(r'(?i)(?<![a-z])\b(trcl|u|lat|fill|vol|tmp|imp:[a-z0-9,]+)\s*=',remaining)
        geom=remaining[:kw.start()].strip() if kw else remaining.strip()
        params=remaining[kw.start():] if kw else ''
        trclmatch=re.search(r'(?i)\btrcl\s*=\s*([^\s]+)',params)
        trcl=None
        if trclmatch:
            val=trclmatch.group(1)
            if not re.fullmatch(r'\d+',val):
                raise GeometryError(f'Komórka {cid}: obsługiwane tylko TRCL=n, nie TRCL={val}')
            trcl=int(val)
            if trcl not in trans: raise GeometryError(f'Komórka {cid}: brak transformacji TR{trcl}')
        for bad in ('fill','lat','u'):
            if re.search(rf'(?i)\b{bad}\s*=',params):
                raise GeometryError(f'Komórka {cid}: {bad.upper()} wymaga obsługi Universe/Lattice. Import przerwany.')
        special=geom.lower().replace(' ','')=='#all'
        parsed=('all',) if special else _parse_bool(geom)
        if cid in cells: raise GeometryError(f'Powtórzona komórka {cid}')
        cells[cid]=Cell(cid,mat,density,parsed,trcl,special)
    if not surfaces or not cells:
        raise GeometryError('Brak [Surface] lub [Cell] w pliku PHITS.')
    if not any(c.material==-1 for c in cells.values()):
        raise GeometryError('Nie znaleziono outer void (komórki z mat=-1).')
    return Geometry(surfaces,cells,trans)
