import sys
from pathlib import Path
import numpy as np
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from phits_geometry import parse_inp, number, GeometryError
from phantom_mesh import generate_mesh, BuildOptions


def make(tmp_path,text):
    p=tmp_path/'input.inp';p.write_text(text,encoding='utf-8');return p


def point(*xyz): return np.array(xyz,dtype=float).reshape((1,1,1,3))


def test_numbers():
    assert number('1.d-3') == pytest.approx(.001)
    assert number('cos(pi/3)') == pytest.approx(.5)
    with pytest.raises(GeometryError): number('__import__("os").system("touch /tmp/a")')


def test_sphere_and_outer(tmp_path):
    g=parse_inp(Path(__file__).resolve().parents[1]/'examples/spheres.inp')
    assert int(g.classify(point(0,0,0)).item())==1
    assert int(g.classify(point(2.5,0,0)).item())==2
    assert int(g.classify(point(4,0,0)).item())==3
    assert int(g.classify(point(5.2,0,0)).item())==99


def test_rotation_surface_and_trcl(tmp_path):
    inp='''
[Transform]
*tr1 0 0 0 90 0 0 0 0 0 0 0 0 2
[Surface]
1 BOX 0 0 0 2 0 0 0 1 0 0 0 1
2 RPP -4 4 -4 4 -4 4
[Cell]
1 1 -1 -1 TRCL=1
2 0 -2 #1
99 -1 2
'''
    g=parse_inp(make(tmp_path,inp))
    assert int(g.classify(point(-.5,1,.5)).item())==1
    assert int(g.classify(point(1,.5,.5)).item())==2
    assert int(g.classify(point(5,0,0)).item())==99
    # Now transform the surface instead of its host cell
    inp=inp.replace('1 BOX','1 1 BOX').replace('-1 TRCL=1','-1')
    g2=parse_inp(make(tmp_path,inp))
    assert int(g2.classify(point(-.5,1,.5)).item())==1


def test_cell_boolean_or_and_complement(tmp_path):
    inp='''
[Surface]
1 SO 1
2 S 3 0 0 1
3 RPP -4 4 -4 4 -4 4
[Cell]
1 1 -1 (-1 : -2)
2 0 -3 #1
99 -1 3
'''
    g=parse_inp(make(tmp_path,inp))
    assert int(g.classify(point(0,0,0)).item())==1
    assert int(g.classify(point(3,0,0)).item())==1
    assert int(g.classify(point(2,0,0)).item())==2
    assert int(g.classify(point(5,0,0)).item())==99


def test_all_keyword(tmp_path):
    inp='''
[Surface]
1 SO 1
2 SO 5
[Cell]
1 1 -1 -1
2 0 #all
99 -1 2
'''
    g=parse_inp(make(tmp_path,inp))
    assert int(g.classify(point(0,0,0)).item())==1
    assert int(g.classify(point(2,0,0)).item())==2
    assert int(g.classify(point(6,0,0)).item())==99


def test_merge_removes_only_same_material_interface(tmp_path):
    inp='''
[Surface]
1 RPP -2 2 -2 2 -2 2
2 PX 0
3 PX 1
[Cell]
1 1 -1 -1 -2
2 1 -1 -1 2 -3
3 2 -1.2 -1 3
99 -1 #1 #2 #3
'''
    g=parse_inp(make(tmp_path,inp))
    opts=BuildOptions((-2.5,2.5,-2.5,2.5,-2.5,2.5),1.5,1.0)
    # Requested pitch must be <= half wall thickness.
    with pytest.raises(GeometryError): generate_mesh(g,opts,tmp_path/'no.stl')
    opts.pitch_mm=.6
    report_all=generate_mesh(g,opts,tmp_path/'all.stl')
    opts.merge_same_material=True
    report_merged=generate_mesh(g,opts,tmp_path/'merged.stl')
    assert report_all['wall_voxels'] > report_merged['wall_voxels'] > 0
    assert report_all['mesh_watertight']
    assert report_merged['mesh_watertight']
    assert not report_all['clipped_faces']


def test_unsupported_fails_instead_of_guessing(tmp_path):
    inp='''
[Surface]
1 SO 2
[Cell]
1 1 -1 -1 FILL=3
99 -1 1
'''
    with pytest.raises(GeometryError,match='Universe'):
        parse_inp(make(tmp_path,inp))


def test_set_variables(tmp_path):
    inp='''
set: c1[2] c2[3*c1]
[Surface]
1 SO c2
2 SO 10
[Cell]
1 1 -1 -1
2 0 1 -2
99 -1 2
'''
    g=parse_inp(make(tmp_path,inp))
    assert int(g.classify(point(5.5,0,0)).item())==1
    assert int(g.classify(point(7,0,0)).item())==2


def test_centered_bounds(tmp_path):
    inp='''
[Surface]
1 SO 1
2 SO 3
[Cell]
1 1 -1 -1
2 0 1 -2
99 -1 2
'''
    g=parse_inp(make(tmp_path,inp))
    report=generate_mesh(g, BuildOptions((-3.2,3.2,-3.2,3.2,-3.2,3.2),2,0.6),tmp_path/'one.stl')
    assert report['mesh_watertight']
    assert report['clipped_faces']==[]
    assert (tmp_path/'one.stl').stat().st_size>1000


def test_transform_variants():
    from phits_geometry import make_transform
    t1=make_transform('*tr1 0 0 0 0 1 0 -1 0 0 0 0 1 1',{})
    assert np.allclose(t1.rotation @ np.array([1.,0.,0.]),[0,1,0])
    t2=make_transform('*tr2 1 0 0 90 0 0 0 0 0 0 0 0 -2',{})
    # M=-2 means translation before rotation with reversed translation sign.
    assert np.allclose(t2.rotation @ np.array([1.,0.,0.])+t2.translation,[0,0,0],atol=1e-10)
    t3=make_transform('*tr3 0 0 0 1 0 0 3 90 0 0 0 0 3',{})
    assert np.allclose(t3.rotation @ np.array([2.,0.,0.])+t3.translation,[1,1,0],atol=1e-10)


def test_surface_continuation(tmp_path):
    g=parse_inp(make(tmp_path,'''\
[Surface]
1 RCC 0 0 0
      0 0 3 1
2 RPP -4 4 -4 4 -4 4
[Cell]
1 1 -1 -1
2 0 1 -2
99 -1 2
'''))
    assert int(g.classify(point(0,0,2)).item())==1


def test_section_headers_with_switch_suffix_and_spaced_names(tmp_path):
    from phits_geometry import parse_inp
    f = tmp_path / "header.inp"
    f.write_text("""[ S u r f a c e ]
 10 SO 2
[ C e l l ]
 1 0 -10
 2 -1 10
[t-track] %switch%
 mesh = xyz
[ T-Deposit ] off $ detector tally
 mesh = xyz
[END]
""")
    g = parse_inp(f)
    assert set(g.surfaces) == {10}
    assert set(g.cells) == {1, 2}

def test_real_jaszczak_section_headers():
    from phits_geometry import parse_inp
    from pathlib import Path
    candidate = Path(__file__).parent / ".." / "examples" / "jaszczak_geometry.inp"
    if candidate.exists():
        g = parse_inp(candidate)
        assert len(g.surfaces) == 312
        assert len(g.cells) == 38
        assert len(g.transforms) == 6
